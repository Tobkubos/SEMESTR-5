#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QString"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    ,calculatorString()
    ,operators()
    ,numbers()
    ,ss()
    ,clearScreen()
    ,wynikDouble()
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
    wynikDouble = 0;
    clearScreen = true;
}


double makeOperation(double a, double b, char operation){
    if(operation == '+'){
        return a + b;
    }

    if(operation == '-'){
        return a - b;
    }

    if(operation == '/'){
        return a / b;
    }

    if(operation == '*'){
        return a * b;
    }

    if(operation == '^'){
        return pow(a, b);
    }

    return 0;
}

bool isOperator(char o){
    if(o == '+' || o == '-' || o == '*' || o == '/' || o == '^'){
        return true;
    }
    return false;
}

int operatorImportance(char o){
    if(o == '+' || o == '-')
        return 1;
    if(o == '*' || o == '/')
        return 2;
    if(o == '^')
        return 3;
    return 0;
}

void MainWindow::on_pushButton_calc_clicked(bool showResult)
{
    ss.str("");
    ss.clear();
    ss << calculatorString.toStdString();

    if (calculatorString.trimmed().isEmpty()) {
        ui->wynik->setText("brak wyrażenia");
        return;
    }

    std::string t;
    while(getline(ss, t, ' ')){
        if(t.empty())
            continue;

        qDebug() << "Fragment stringa (t):" << QString::fromStdString(t);
        if(isdigit(t[0])){
            double number;
            std::stringstream(t) >> number;
            numbers.push(number);
        }
        else if(isOperator(t[0])){
            char oprtr = t[0];

            while (!operators.empty() && operatorImportance(operators.top()) >= operatorImportance(oprtr)){

                if (numbers.size() < 2) {
                    MainWindow::ResetCalculator("niepoprawne dzialanie");
                    return;
                }

                qDebug() << "operatory" << operatorImportance(operators.top()) << " "<< operatorImportance(oprtr);
                double b = numbers.top();
                numbers.pop();
                double a = numbers.top();
                numbers.pop();
                char oprtr = operators.top();
                operators.pop();

                if (oprtr == '/' && b == 0) {
                    MainWindow::ResetCalculator("dzielenie przez 0!");
                    return;
                }

                numbers.push(makeOperation(a,b,oprtr));
            }
            operators.push(oprtr);
        }
    }

    while(!operators.empty()){

        if (numbers.size() < 2) {
            MainWindow::ResetCalculator("niepoprawne dzialanie");
            return;
        }

        double b = numbers.top();
        numbers.pop();
        double a = numbers.top();
        numbers.pop();
        char oprtr = operators.top();
        operators.pop();

        if (oprtr == '/' && b == 0) {
            MainWindow::ResetCalculator("dzielenie przez 0!");
            return;
        }
        numbers.push(makeOperation(a,b,oprtr));
    }

    if(!numbers.empty()){
        wynikDouble = numbers.top();
    }else{
        wynikDouble = 0;
    }


    //ui->wynik->setText(QString::number(numbers.top()));
      ui->wynik->setText(QString::number(wynikDouble));
    //ui->historia->setText(ui->historia->text() += calculatorString + " = " + QString::number(numbers.top()) + "\n");
      qDebug() << showResult;
      ui->historia->setText(ui->historia->text() += calculatorString + " = " + QString::number(wynikDouble) + "\n");
      clearScreen = true;
}

void MainWindow::on_pushButton_sin_clicked()
{
    MainWindow::on_pushButton_calc_clicked();
    calculatorString = "sin( " + QString::number(wynikDouble) + " )";
    wynikDouble = sin(wynikDouble);
    ui->wynik->setText(QString::number(wynikDouble));
    ui->historia->setText(ui->historia->text() += calculatorString + " = " + QString::number(wynikDouble) + "\n");
}

void MainWindow::on_pushButton_cos_clicked()
{
    MainWindow::on_pushButton_calc_clicked(false);
    calculatorString = "cos( " + QString::number(wynikDouble) + " )";
    wynikDouble = cos(wynikDouble);
    ui->wynik->setText(QString::number(wynikDouble));
    ui->historia->setText(ui->historia->text() += calculatorString + " = " + QString::number(wynikDouble) + "\n");
}

void MainWindow::on_pushButton_tg_clicked()
{
    MainWindow::on_pushButton_calc_clicked(false);
    calculatorString = "tg( " + QString::number(wynikDouble) + " )";
    wynikDouble = tan(wynikDouble);
    ui->wynik->setText(QString::number(wynikDouble));
    ui->historia->setText(ui->historia->text() += calculatorString + " = " + QString::number(wynikDouble) + "\n");
}

void MainWindow::on_pushButton_ctg_clicked()
{
    MainWindow::on_pushButton_calc_clicked(false);
    calculatorString = "ctg( " + QString::number(wynikDouble) + " )";
    wynikDouble = 1 / tan(wynikDouble);
    ui->wynik->setText(QString::number(wynikDouble));
    ui->historia->setText(ui->historia->text() += calculatorString + " = " + QString::number(wynikDouble) + "\n");
}

void MainWindow::on_pushButton_abs_clicked()
{
    MainWindow::on_pushButton_calc_clicked(false);
    calculatorString = "| " + QString::number(wynikDouble) + " |";
    wynikDouble = abs(wynikDouble);
    ui->wynik->setText(QString::number(wynikDouble));
    ui->historia->setText(ui->historia->text() += calculatorString + " = " + QString::number(wynikDouble) + "\n");
}

void MainWindow::on_pushButton_del_clicked()
{
    calculatorString.clear();
    calculatorString = "WYCZYSZCZONO!";

    ui->wynik->clear();
    ui->wynik->setText(calculatorString);
    while(operators.empty() == false){
        operators.pop();
    }
    while(numbers.empty() == false){
        numbers.pop();
    }

    clearScreen = true;
}

void MainWindow::ResetCalculator(QString errorMessage){
    calculatorString.clear();

    ui->wynik->clear();
    ui->wynik->setText(errorMessage);
    while(operators.empty() == false){
        operators.pop();
    }
    while(numbers.empty() == false){
        numbers.pop();
    }

    clearScreen = true;
}

void MainWindow::checkClearScreen()
{
    if (clearScreen) {
        calculatorString.clear();
        clearScreen = false;
    }
}
void MainWindow::on_pushButton_0_clicked()
{
    checkClearScreen();
    calculatorString += "0";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_1_clicked()
{
    checkClearScreen();
    calculatorString += "1";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_2_clicked()
{
    checkClearScreen();
    calculatorString += "2";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_3_clicked()
{
    checkClearScreen();
    calculatorString += "3";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_4_clicked()
{
    checkClearScreen();
    calculatorString += "4";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_5_clicked()
{
    checkClearScreen();
    calculatorString += "5";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_6_clicked()
{
    checkClearScreen();
    calculatorString += "6";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_7_clicked()
{
    checkClearScreen();
    calculatorString += "7";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_8_clicked()
{
    checkClearScreen();
    calculatorString += "8";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_9_clicked()
{
    checkClearScreen();
    calculatorString += "9";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_plus_clicked()
{
    checkClearScreen();
    calculatorString += " + ";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_substract_clicked()
{
    checkClearScreen();
    calculatorString += " - ";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_divide_clicked()
{
    checkClearScreen();
    calculatorString += " / ";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_multiply_clicked()
{
    checkClearScreen();
    calculatorString += " * ";
    ui->wynik->setText(calculatorString);
}

void MainWindow::on_pushButton_pow_clicked()
{
    checkClearScreen();
    calculatorString += " ^ ";
    ui->wynik->setText(calculatorString);
}






