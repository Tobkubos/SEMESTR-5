#include <iostream>
#include <sstream>
#include <gtk/gtk.h>

#if defined(_WIN32) || defined(WIN32)
//    #include <gdk/gdkwin32.h>
#elif defined(__unix__) || defined(__unix) || defined(unix) || defined(__linux__) || defined(__linux) || defined(linux) || defined(__gnu_linux__)
#else
#endif


// ========================================================================================================================

    GtkBuilder  *gbuilder;
    GError      *gerror = NULL;

    GtkWidget   *gtk_MenuWindow;
    GtkWidget   *gtk_StartButton;
    GtkWidget   *gtk_Title;
    GtkWidget   *gtk_DifficultyLabel;
    GtkWidget   *gtk_ComboBox;

    GtkWidget   *gtk_GameWindow;
    GtkWidget   *gtk_timeLabel;
    GtkWidget   *gtk_timeCountdown;

    GtkWidget   *gtk_GameOverWindow;
    GtkWidget   *gtk_GameOverLabel;
    GtkWidget   *gtk_Score;
    GtkWidget   *gtk_Missed;
    GtkWidget   *gtk_typeGame;

    GtkWidget   *gtk_gameButton;
    GtkWidget   *gtk_fixedLayout;
    int score = 0;
    int missed = 0;
// ========================================================================================================================


void show_button_random_pos();
// ========================================================================================================================
int countdown_value = 100; // Wartość początkowa odliczania
float cooldown_button_value = 3;
float tempCooldown = 0;

// Funkcja aktualizująca tekst w label
gboolean update_countdown(gpointer data) {
    if (countdown_value <= 0) {
        gtk_widget_hide(gtk_GameWindow);
        gtk_label_set_text(GTK_LABEL(gtk_timeCountdown), "Koniec!");
        gtk_widget_show ( gtk_GameOverWindow );

        std::ostringstream wynik;
        wynik << score << " punktów";
        gtk_label_set_text(GTK_LABEL(gtk_Score), wynik.str().c_str());

        std::ostringstream nietraf;
        nietraf << missed << " spóźnionych";
        gtk_label_set_text(GTK_LABEL(gtk_Missed), nietraf.str().c_str());

        int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(gtk_ComboBox));

        if(active_index == 0){
            gtk_label_set_text(GTK_LABEL(gtk_typeGame), "Tryb gry: Leniwy");
        }

        if(active_index == 1){
            gtk_label_set_text(GTK_LABEL(gtk_typeGame), "Tryb gry: Normalny");
        }

        if(active_index == 2){
            gtk_label_set_text(GTK_LABEL(gtk_typeGame), "Tryb gry: PRO");
        }

        gtk_widget_hide(gtk_GameWindow);
        return FALSE; // Zatrzymanie timera
    }

    // Aktualizacja tekstu w etykiecie
    std::ostringstream oss;
    oss << countdown_value << " sekund";
    gtk_label_set_text(GTK_LABEL(gtk_timeCountdown), oss.str().c_str());

    countdown_value--;
    return TRUE; // Kontynuacja timera
}

gboolean update_cooldown_button(gpointer data) {
    if (cooldown_button_value <= 0) {
        missed++;
        show_button_random_pos();
        cooldown_button_value = tempCooldown;
    }

    cooldown_button_value-=0.1;
    return TRUE; // Kontynuacja timera
}

// Funkcja uruchamiająca odliczanie
void StartCounting() {
    countdown_value = 10; // Reset odliczania
    g_timeout_add(1000, update_countdown, NULL); // Uruchomienie timera co 1000 ms (1 sekunda)
}

void StartCooldown() {
    cooldown_button_value = tempCooldown; // Reset odliczania
    g_timeout_add(100, update_cooldown_button, NULL); // Uruchomienie timera co 100 ms (1 sekunda)
}

void on_window_main_destroy () {
    gtk_main_quit ();
}

void on_button_click(GtkWidget *widget, gpointer data) {
    score++;
    std::cout<<score<<std::endl;
    gtk_widget_hide(gtk_MenuWindow);
    show_button_random_pos();
    cooldown_button_value = tempCooldown;
}
void show_button_random_pos(){
    if (rand() == 0) {
            srand(time(0)); // Tylko raz na początek programu
        }

    // Losowe współrzędne w granicach okna gry
    int x = rand() % 1200;  // Współrzędna X w zakresie od 0 do 1199
    int y = rand() % 800;   // Współrzędna Y w zakresie od 0 do 799


    // Pokaż przycisk
    gtk_fixed_move(GTK_FIXED(gtk_fixedLayout), gtk_gameButton, x, y);
    gtk_widget_show(gtk_gameButton);
}

void on_start_button_clicked(GtkWidget *widget, gpointer data) {
    // Ukrycie głównego okna

    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(gtk_ComboBox));
    if(active_index == 0){
        tempCooldown = 2;
    }
    if(active_index == 1){
        tempCooldown = 1;
    }
    if(active_index == 2){
        tempCooldown = 0.5;
    }

    gtk_widget_hide(gtk_MenuWindow);


    // Pokazanie okna gry
    gtk_widget_show(gtk_GameWindow);
    StartCounting();
    StartCooldown();

    gtk_widget_hide(gtk_gameButton);
    show_button_random_pos();

}



// ========================================================================================================================
// Funkcja do ładowania stylów CSS
void load_css() {
    GtkCssProvider *provider = gtk_css_provider_new();
    GdkDisplay *display = gdk_display_get_default();
    GdkScreen *screen = gdk_display_get_default_screen(display);

    gtk_style_context_add_provider_for_screen(
        screen,
        GTK_STYLE_PROVIDER(provider),
        GTK_STYLE_PROVIDER_PRIORITY_USER
    );

    GError *error = NULL;

    // Załaduj styl CSS z domyślnego katalogu projektu
    gtk_css_provider_load_from_path(provider, "style.css", &error);

    if (error) {
        std::cerr << "Nie udało się załadować stylu CSS: " << error->message << std::endl;
        g_error_free(error);
    } else {
        std::cout << "Styl CSS załadowany pomyślnie!" << std::endl;
    }

    g_object_unref(provider); // Zwolnienie pamięci
}
// ========================================================================================================================

int main( int argc, char *argv[]) {

    gtk_init(&argc, &argv);


    // Wczytamy widgety z pliku *.glade za pomocą GtkBuilder
    gbuilder = gtk_builder_new();
    if ( !gtk_builder_add_from_file(gbuilder, "gra.glade", &gerror) ) { // jeśli wystąpił błąd
        // Można zapisać do pliku: "GBuilder error: " + std::string(gerror->message)
        g_free( gerror );
        return( 1 ); // Wyjście z programu z kodem informacji o błędzie
    }

    gtk_MenuWindow = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "menuWindow" ) );
    gtk_StartButton = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "startButton" ) );
    gtk_Title = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "titleLabel" ) );
    gtk_DifficultyLabel = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "difficultyLabel" ) );
    gtk_ComboBox = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "comboBox" ) );


    gtk_fixedLayout = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "MyLayout" ) );
    gtk_GameWindow = GTK_WIDGET(gtk_builder_get_object(gbuilder, "gameWindow"));
    gtk_gameButton = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "gameButton" ) );
    gtk_timeLabel = GTK_WIDGET( gtk_builder_get_object( gbuilder, "timeLabel" ) );
    gtk_timeCountdown = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "timeCountdown" ) );

    gtk_GameOverWindow = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "gameOverWindow" ) );
    gtk_Score = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "score" ) );
    gtk_Missed = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "missed" ) );
    gtk_GameOverLabel = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "gameOverLabel" ) );
    gtk_typeGame = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "typeGame" ) );

    gtk_widget_set_name(gtk_MenuWindow, "menuWindow");
    gtk_widget_set_name(gtk_StartButton, "startButton");
    gtk_widget_set_name(gtk_Title, "titleLabel");
    gtk_widget_set_name(gtk_DifficultyLabel, "difficultyLabel");

    gtk_widget_set_name(gtk_timeLabel, "timeLabel");
    gtk_widget_set_name(gtk_timeCountdown, "timeCountdown");
    gtk_widget_set_name(gtk_GameWindow, "gameWindow");
    gtk_widget_set_name(gtk_gameButton, "gameButton");

    gtk_widget_set_name(gtk_GameOverWindow, "gameOverWindow");
    gtk_widget_set_name(gtk_Score, "score");
    gtk_widget_set_name(gtk_Missed, "missed");
    gtk_widget_set_name(gtk_GameOverLabel, "gameOverLabel");
    gtk_widget_set_name(gtk_typeGame, "typeGame");

    gtk_builder_connect_signals( gbuilder, NULL );  // Automatyczne podpięcie funkcji do sygnałów określonych w Glade (tutaj nie używamy)

    g_object_unref ( G_OBJECT( gbuilder ) );     // Można już usunąć gbuilder


    load_css();

    g_signal_connect(gtk_StartButton, "clicked", G_CALLBACK(on_start_button_clicked), NULL);
    g_signal_connect(gtk_MenuWindow, "destroy", G_CALLBACK(on_window_main_destroy), NULL);
    g_signal_connect(gtk_GameWindow, "destroy", G_CALLBACK(on_window_main_destroy), NULL);
    g_signal_connect(gtk_GameOverWindow, "destroy", G_CALLBACK(on_window_main_destroy), NULL);
    g_signal_connect(gtk_gameButton, "clicked", G_CALLBACK(on_button_click), NULL);


    // Ustaw rozmiar głównego okna
    gtk_window_set_default_size ( GTK_WINDOW(gtk_MenuWindow), 500, 550 );
    gtk_window_set_default_size ( GTK_WINDOW(gtk_GameWindow), 1400, 900 );
    gtk_window_set_default_size ( GTK_WINDOW(gtk_GameOverWindow), 500, 250 );
    // Ustaw okno w centrum głównego ekranu
    gtk_window_set_position ( GTK_WINDOW(gtk_MenuWindow), GTK_WIN_POS_CENTER );
    gtk_window_set_position ( GTK_WINDOW(gtk_GameWindow), GTK_WIN_POS_CENTER );
    gtk_window_set_position ( GTK_WINDOW(gtk_GameOverWindow), GTK_WIN_POS_CENTER );

    // A jak zmienić tytuł głównego okienka?
    gtk_window_set_title(GTK_WINDOW(gtk_MenuWindow), "G R A   N A   R E F L E X --- MENU");
    gtk_window_set_title(GTK_WINDOW(gtk_GameWindow), "G R A   N A   R E F L E X --- GRA");
    gtk_window_set_title(GTK_WINDOW(gtk_GameOverWindow), "G R A   N A   R E F L E X --- WYNIK");
    // Pokaż główne okno
    gtk_widget_show ( gtk_MenuWindow );

    gtk_main(); // W tej pętli program okienkowy tkwi, dopóki go nie zakończymy przyciskiem 'X'


// ========================================================================================================================

    // Zakończenie przeniesiono do on_window_main_destroy

    return 0;
}
